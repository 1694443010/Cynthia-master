/**
 *
 */
package com.sogou.qadev.service.cynthia.bean;

/**
 * @description:data modify execute time
 * @author:liming
 * @mail:liming@sogou-inc.com
 * @date:2014-5-6 下午3:14:21
 * @version:v1.0
 */
public enum ExecuteTime {
	afterQuery, beforeCommit, afterSuccess, afterFail;
}
