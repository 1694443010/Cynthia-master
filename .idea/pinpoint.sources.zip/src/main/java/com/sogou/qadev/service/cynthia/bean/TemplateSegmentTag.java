package com.sogou.qadev.service.cynthia.bean;

public class TemplateSegmentTag extends SegmentTagBase {
	public TemplateSegmentTag()
	{
		super();
	}
	
	public UUID id = null;
	public String name = null;
}
