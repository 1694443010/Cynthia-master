package com.sogou.qadev.service.cynthia.util;

public class JsonConfig {
}
