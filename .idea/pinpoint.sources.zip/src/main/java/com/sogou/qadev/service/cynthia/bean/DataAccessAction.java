/**
 * 
 */
package com.sogou.qadev.service.cynthia.bean;

/**
 * @description:data opreate enum
 * @author:liming
 * @mail:liming@sogou-inc.com
 * @date:2014-5-6 下午3:12:11
 * @version:v1.0
 */
public enum DataAccessAction
{
	insert, update, delete, read;
}