package com.sogou.qadev.service.cynthia.bean;

public class TemplateTypeSegmentTag extends SegmentTagBase {
	public TemplateTypeSegmentTag()
	{
		super();
	}

	public UUID templateTypeId = null;
	
	public String templateTypeName = null;
}
